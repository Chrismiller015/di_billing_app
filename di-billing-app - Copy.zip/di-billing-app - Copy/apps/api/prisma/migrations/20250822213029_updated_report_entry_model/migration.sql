-- AlterTable
ALTER TABLE "public"."ReportEntry" ADD COLUMN     "isPrimary" BOOLEAN,
ADD COLUMN     "specificAccountName" TEXT;
