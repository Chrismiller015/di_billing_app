-- AlterTable
ALTER TABLE "public"."ReportEntry" ADD COLUMN     "specificSalesforceId" TEXT;
